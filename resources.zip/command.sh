racket driver.rkt t0.in > t0.out
