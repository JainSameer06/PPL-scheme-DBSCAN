racket driver.rkt t0.in > t0.out
racket driver.rkt t1.in > t1.out
racket driver.rkt t2.in > t2.out
racket driver.rkt t3.in > t3.out
racket driver.rkt t4.in > t4.out
